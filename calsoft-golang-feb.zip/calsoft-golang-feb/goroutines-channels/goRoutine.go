// package main

// import (
// 	"fmt"
// )


// func PrintMessage(message string) {
// 	fmt.Println("inside")
	
// 	fmt.Println("ended ")
// }

// func main() {

// 	fmt.Println("hello from main")
// 	go PrintMessage("hello from abhi")
// 	fmt.Println("hello from exit")
// 	//time.Sleep(time.Second*6)
// 	//.Println("hello from main after 3 seconds")
// 	// prefixing go keyword : it becomes goroutine.

// }

// // go run main.go==> no output from our go PrintMessage("hello from abhi")
// // fmt.Println("hello from main") ==> it ends the execution of main 
// // fmt.Println("hello from main")
// // fmt.Println("hello from exit")
// // line 31 and 32 are the code lines from your main function
// // i.e. ==> main goroutine.
// // main goroutine is the goroutine that is created when we run the program.
// // main goroutine is existing before the child goroutine.


          +------------------+
          |  Start Goroutine |
          +------------------+
                   |
                   v
          +------------------+
          |    Runnable      |  (Waiting to be scheduled)
          +------------------+
                   |
                   v
          +------------------+
          |    Running       |  (Executing on CPU)
          +------------------+
            |      |      |
       +----+      |      +----+
       |           |           |
       v           v           v
+--------------+  +--------------+  +--------------+
|  Waiting I/O |  |  Waiting for |  |  Waiting on |
|  (Blocked)   |  |  Channel     |  |  Timer      |
+--------------+  +--------------+  +--------------+
       |           |           |
       +----+      |      +----+
            |      |      |
            v      v      v
      +------------------+
      |    Reschedule    |
      |    (Runnable)    |
      +------------------+
                   |
                   v
         +-------------------+
         |   Completed/Exit  | (Goroutine Ends)
         +-------------------+
