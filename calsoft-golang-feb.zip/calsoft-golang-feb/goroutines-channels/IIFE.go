package main

import "fmt"

func main2()  {

	func ()  {
		fmt.Println("hello from go")
	}()

}

// 