// package main

// import "fmt"

// func main() {
//     func() {
//         fmt.Println("Opening resource...")
//         defer fmt.Println("Closing resource...") // Deferred execution
//         fmt.Println("Using resource...")
//     }()
// 	 fmt.Println("inside the main ...")
// }

package main

import "fmt"

func main4() {
    func() {
        fmt.Println("Opening resource...")

        // Defer a function that acts as a `finally` block
        defer func() {
            if err := recover(); err != nil {
                fmt.Println("Recovered from panic:", err) // Equivalent to `catch`
            }
            fmt.Println("Closing resource...") // Equivalent to `finally`
        }()

        fmt.Println("Using resource...")

        // Simulate an error (equivalent to throwing an exception)
        panic("Something went wrong!")

        fmt.Println("This will not execute since panic stops execution.")
    }()
}
