// // immediate computed strategy

// package main

// import "fmt"

// func main() {
//     factorial,facts := func(n int) (int,int) {
//         if n==0 {
// 			return 1,10
// 		}
// 		return n, 10
//     }(5) // Calculates factorial(5)
// // factorial of 5 ==>IIFE , no loop, 
//     fmt.Println("Factorial:", factorial,facts) // Output: 120
// }



// import concurrent.futures
// import time

// # Worker function
// def worker(task_id):
//     print(f"Task {task_id} started by {threading.current_thread().name}")
//     time.sleep(2)  # Simulating work
//     print(f"Task {task_id} finished by {threading.current_thread().name}")
//     return f"Result of Task {task_id}"

// # Number of tasks and worker threads
// num_tasks = 10
// num_workers = 5

// # Using ThreadPoolExecutor to manage worker threads
// with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers) as executor:
//     # Submitting tasks
//     future_to_task = {executor.submit(worker, i): i for i in range(num_tasks)}

//     # Collecting results
//     for future in concurrent.futures.as_completed(future_to_task):
//         task_id = future_to_task[future]
//         try:
//             result = future.result()
//             print(result)
//         except Exception as e:
//             print(f"Task {task_id} generated an exception: {e}")

// print("All tasks completed.")
