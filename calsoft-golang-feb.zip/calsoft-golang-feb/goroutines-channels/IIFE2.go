package main

import "fmt"

func main3() {
    config := func() string {
        fmt.Println("Initializing configuration...")
        return "Config Loaded"
    } ()// Immediately invoked

    fmt.Println(config) // Output: Config Loaded
}


