package main

import (
	"fmt"
	"sync"
	"time"
)

func PrintMessage2(message string, wg *sync.WaitGroup) {
	defer func() {
		fmt.Println("inside the defer PM2")
            wg.Done()
        }()
	
	
	fmt.Println("inside PM2")
	for i := 0; i < 20; i++ {
		fmt.Println(message, i)
		time.Sleep(time.Millisecond * 1000)
	}
	fmt.Println("ended PM@")
}
func PrintMessage(message string, wg *sync.WaitGroup) {
	defer func() {
		fmt.Println("inside the defer")
            wg.Done()
        }()
	
	
	fmt.Println("inside")
	for i := 0; i < 10; i++ {
		fmt.Println(message, i)
		time.Sleep(time.Millisecond * 500)
	}
	fmt.Println("ended ")
}

func main() {

	fmt.Println("hello from main")
	
	var wg sync.WaitGroup
	wg.Add(1)
	// if the delta is +ve it increases the counter , ==>
	// more goroutines are expected to finish before Wait can proceed.

	
	go PrintMessage("hello from abhi", &wg)
	go PrintMessage2("hello from abhi PM2", &wg)
	fmt.Println("hello from exit")
	
	wg.Wait()
	// unless and untill it is getting Done confirmation from 
	// the all goroutines.
	
	//.Println("hello from main after 3 seconds")
	// prefixing go keyword : it becomes goroutine.

}