package main

import (
	"fmt"
)

// this import will help to include the packages for our current file.
//fmt : Format package is used to print the output on the console.

func main(){

	fmt.Println("Hello World")
	// this will print the output on the console.
}

