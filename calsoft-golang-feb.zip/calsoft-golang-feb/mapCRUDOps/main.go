package main

import (
	"fmt"

	"github.com/go-playground/validator/v10"
)

// do the name validation
// the length of the name should be 2 to 10 chars.
// if the length is in between 2 to 10 is fine else throw the error
// called invalid name

// struct is an user defined type which allows u to group all related
// fields / variables under one roof.
// it is similar to class from java but no methods no inheritance.
// we will use the struct to hold complex data structures (class )

type Person struct {
	Name string `validate:"min=2,max=10"`
}
// func checkName(name string)(bool, error) {
// 	if len(name)>=2 && len(name)<=10{
// 		return true, nil
// 	}
// 	return false, fmt.Errorf("%d length is not valid",len(name))
// }

func main(){

	validate :=validator.New()

	persons :=[]Person{
		{Name: "Abhi"},
		{Name: "ab"},
		{Name:"a"},// below min
		{Name: "Abhinandan"},// exact max
		{Name:"SwamyVishwanath"},// above max
	}
	persons = append(persons, Person{Name:"advik"})

	fmt.Println(persons)

	for _,person := range persons{

		err:= validate.Struct(person)

		if err!=nil {
			fmt.Printf("Invalid :%s (%v)", person.Name,err)
			//he %v verb is useful for printing values without specifying their type explicitly.
		}
		fmt.Println(person.Name)
	}

	//name :="a"
	//result , err :=checkName(name)


	// if err!=nil {
	// 	fmt.Println(err)
	// }

	// fmt.Println(name,result)

}
// 1. Validator package(predefined type)
// 2. when to fmt.errorF

