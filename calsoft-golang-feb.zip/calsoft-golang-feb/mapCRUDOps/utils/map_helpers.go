package utils

// // create a map of type map[int]string
// // here key is of type int and value is of type string
// // methodName : createMap
// // return type : map[int]string
// // map[key]value
// func CreateMap() map[int]string {
// 	// func : to declare the function
// 	// createMap : function name
// 	// map[int]string : return type of the function
// 	// return nil
// 	return make(map[int]string)
// 	// make
// 	// make is a built-in function that creates a map of the specified type @ the runtime

// 	// map[key] value : type specs

// 	// return nill
// }
// // REST : post : will u return the newly created resource or failure message

// // should return the whole map
// // should return the newly created key value pair

// // declare the function
// // will return the complete map

// func AddOrUpdateElement(m map[int]string, key int, value string) map[int]string {
// 	// add element to the map
// 	// return the map
// 	// return the newly created key value pair
// 	m[key] = value
// 	return m
// }

import "fmt"

// CreateMap initializes a new map with int keys and string values
func CreateMap() map[int]string {
	return make(map[int]string)
}

// AddOrUpdate adds or updates a key-value pair in the map and returns the updated map
func AddOrUpdate(m map[int]string, key int, value string) map[int]string {
	m[key] = value
	return m
}

// GetValue retrieves a value from the map and checks if it exists
func GetValue(m map[int]string, key int) (string, bool) {

	value , exists:= m[key]// value , status 
	fmt.Println(m[key])
	//exists := false
	return value, exists
}

// DeleteKey removes a key-value pair from the map and returns the updated map
func DeleteKey(m map[int]string, key int) map[int]string {
	delete(m, key)
	return m
}

// IterateMap iterates over the map and returns a slice of key-value pairs
func IterateMap(m map[int]string) []string {
	var result []string
	for key, value := range m {
		result = append(result, fmt.Sprintf("Key: %d, Value: %s", key, value))
	}
	return result
}

// GetLength returns the length of the map
func GetLength(m map[int]string) int {
	return len(m)
}

// ClearMap resets the map to an empty state and returns it
func ClearMap(m map[int]string) map[int]string {
	for key := range m {
		delete(m, key)
	}
	return m
}

// KeyExists checks if a given key exists in the map
func KeyExists(m map[int]string, key int) bool {
	_, exists := m[key]
	return exists
}

// MergeMaps merges two maps and returns the resulting map
func MergeMaps(m1, m2 map[int]string) map[int]string {
	for key, value := range m2 {
		m1[key] = value
	}
	return m1
}

// GetKeys returns all keys of the map as a slice
func GetKeys(m map[int]string) []int {
	keys := make([]int, 0, len(m))
	for key := range m {
		keys = append(keys, key)
	}
	return keys
}

// GetValues returns all values of the map as a slice
func GetValues(m map[int]string) []string {
	values := make([]string, 0, len(m))
	for _, value := range m {
		values = append(values, value)
	}
	return values
}

// CloneMap creates a copy of the given map and returns it
func CloneMap(m map[int]string) map[int]string {
	clone := make(map[int]string)
	for key, value := range m {
		clone[key] = value
	}
	return clone
}

