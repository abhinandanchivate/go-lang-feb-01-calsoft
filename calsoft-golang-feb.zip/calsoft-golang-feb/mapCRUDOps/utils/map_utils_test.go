package utils

import (
	"testing"
)

// Test CreateMap
func TestCreateMap(t *testing.T) {
	// testing.T is a type and t is a variable of type testing.T
	// which is used for testing the code
	// t is a variable of type testing.T
	// * is a pointer 
	m := CreateMap()
	m[1] = "Apple"
	if len(m) != 0 {
		t.Errorf("Expected empty map, got length %d", len(m))
	}
}

// Test AddOrUpdate
func TestAddOrUpdate(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")

	if len(m) != 1 {
		t.Errorf("Expected map length 1, got %d", len(m))
	}
	if val, exists := m[1]; !exists || val != "Apple" {
		t.Errorf("Expected key 1 to have value 'Apple', got '%s'", val)
	}
}

// Test GetValue
func TestGetValue(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")

	val, exists := GetValue(m, 1)
	if !exists || val != "Apple" {
		t.Errorf("Expected 'Apple', got '%s'", val)
	}

	_, exists = GetValue(m, 99)
	if exists {
		t.Errorf("Expected key 99 to not exist")
	}
}

// Test DeleteKey
func TestDeleteKey(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")
	m = DeleteKey(m, 1)

	if len(m) != 0 {
		t.Errorf("Expected empty map after deletion, got length %d", len(m))
	}
}

// Test IterateMap
func TestIterateMap(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")
	m = AddOrUpdate(m, 2, "Banana")

	result := IterateMap(m)
	if len(result) != 2 {
		t.Errorf("Expected 2 entries, got %d", len(result))
	}
}

// Test GetLength
func TestGetLength(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")

	if GetLength(m) != 1 {
		t.Errorf("Expected length 1, got %d", GetLength(m))
	}
}

// Test ClearMap
func TestClearMap(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")
	m = ClearMap(m)

	if len(m) != 0 {
		t.Errorf("Expected empty map, got length %d", len(m))
	}
}

// Test KeyExists
func TestKeyExists(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")

	if !KeyExists(m, 1) {
		t.Errorf("Expected key 1 to exist")
	}
	if KeyExists(m, 99) {
		t.Errorf("Expected key 99 to not exist")
	}
}

// Test MergeMaps
func TestMergeMaps(t *testing.T) {
	m1 := CreateMap()
	m1 = AddOrUpdate(m1, 1, "Apple")

	m2 := CreateMap()
	m2 = AddOrUpdate(m2, 2, "Banana")

	merged := MergeMaps(m1, m2)

	if len(merged) != 2 {
		t.Errorf("Expected length 2 after merge, got %d", len(merged))
	}
}

// Test GetKeys
func TestGetKeys(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")
	m = AddOrUpdate(m, 2, "Banana")

	keys := GetKeys(m)
	if len(keys) != 2 {
		t.Errorf("Expected 2 keys, got %d", len(keys))
	}
}

// Test GetValues
func TestGetValues(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")
	m = AddOrUpdate(m, 2, "Banana")

	values := GetValues(m)
	if len(values) != 2 {
		t.Errorf("Expected 2 values, got %d", len(values))
	}
}

// Test CloneMap
func TestCloneMap(t *testing.T) {
	m := CreateMap()
	m = AddOrUpdate(m, 1, "Apple")

	cloned := CloneMap(m)
	if len(cloned) != len(m) {
		t.Errorf("Expected cloned map to have same length, got %d", len(cloned))
	}
	if cloned[1] != m[1] {
		t.Errorf("Expected cloned value 'Apple', got '%s'", cloned[1])
	}
}
