package main

import "fmt"

// Remove an element at index `i`
func removeElement(s []int, i int) []int {
    return append(s[:i], s[i+1:]...)
	// append(s[2] : slices th array from begining up to 2nd index [it will not include 
	// 2nd index i.e. 0, 1 ])
	// s[4] ... ==> 4th index onwards you pls ttake all the elements till the end 
	// append will join thse two parts and return the same.
	
}

func main2() {
    numbers := []int{1, 2, 3, 4, 5}

    numbers = removeElement(numbers, 2) // Remove element at index 2 (value 3)

    fmt.Println("Slice after removal:", numbers)
}