package main

import (
	"fmt"
	"unsafe"
)

// import "fmt"
// func changeValue(val *int) { // call by value of call by ref.
// 	// val *int = &x
// 	// wehnever we will accept pointer as an argument
// 	// call by ref.

//     *val = 10 // overridden
// 	// *(&x) = 10
// 	// * value of (x ) = 10
// 	// scope of val from changeValue function ?
// }

// // func main() {
// //     x := 42
// //     changeValue(&x)
// //     fmt.Println(x) // Still 42

// // }

// // swapping of 2 numbers using pointer
// func swap(a *int, b *int) {
// 	*a, *b = *b, *a
// 	}
// 	func main() {
// 		a := 5
// 		b := 10
// 		swap(&a, &b)
// 		fmt.Println(a, b) // 10 5
// 		}

// 		// we were using pointer to return the multiple values
// 		// how ==> direclty doing the changes into the location

// // swapping of 2 numbers without using pointer
// func swap2(a int, b int) (int, int) {
// 	return b, a
// 	} // primitives
// 	// array , slice , map
// 	// struct

// type Person struct {
//     Name string
//     Age  int
// }

// func modifyPerson(p *Person) {
//     p.Age = 30
// }

// func main() {
//     p := Person{"John", 25}
//     modifyPerson(&p)
//     fmt.Println(p.Age) // 30
// }

// func main() {

// 	var p *bool =new(bool)// dynamic allocation// malloc
// 	//new function will help u to create a dynmic allocation.

// 	*p = true
// 	fmt.Println(*p) /// not initialized
// }

// pointer to an arrray
// only one .

// func modifyArray(arr *[3]int) {
// 	// 3 pointer variables . which will refer inidividaul
// 	// indexes vai [] .
//     arr[0] = 100  // Modifying the first element
// 	arr[1] = 200
// 	arr[1] = 300
// 	//arr[2] = 400
// }

// func main() {
//     nums := [3]int{1, 2, 3}
//     fmt.Println("Before:", nums)

//     modifyArray(&nums) // Pass array pointer
//     // &nums[0]
//     fmt.Println("After:", nums)
// }

// package main

// import "fmt"

// func modifySlice(s *[]int) {
//     (*s)[0] = 500
//     *s = append(*s, 99)  // Appending a new element
// }

// func main() {
//     numbers := []int{10, 20, 30}
//     fmt.Println("Before:", numbers)

//     modifySlice(&numbers)  // Passing slice pointer

//     fmt.Println("After:", numbers)  // Modified in place
// }
// package main

// import "fmt"

func modifyMap(m *map[string]int) {
    fmt.Println(*m)
	(*m)["a"] = 500   // Modifying existing key
    (*m)["new"] = 999 // Adding new key
	fmt.Println(*m)
	fmt.Println("address value is ",unsafe.Pointer(m))
    *m = map[string]int{"x": 1, "y": 2,"z":3} // Completely replacing the map
	fmt.Println("after new assignemnt address value is ", unsafe.Pointer(m))
}

func main() {
    data := map[string]int{"a": 100, "b": 200}
    fmt.Println("Before:", data)
    fmt.Println(unsafe.Pointer(&data))
   modifyMap(&data)  // Pass map pointer
    
    fmt.Println("After:", data)
}
// Employee e = new Employee()
// Employee e2 = new Employee()
// e2 = e 
