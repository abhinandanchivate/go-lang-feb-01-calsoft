package main

import "fmt"

func main2()  {
	// how to declare a pointer
	var p *int
	// it is used to hold the address
	var a int = 10
	p = &a
	// p will refer to the address of a
	fmt.Println("address of a:", &a)
	// to get the address ==> & is address operator
	fmt.Println("value of p:", p)
	fmt.Println("value at address p:", *p)
	// * is dereference operator
	// used to retrieve the value from the location
	// *p==> *(&a)===> * will inform to retrieve the value from &a

	fmt.Println("value of a ",a)
}