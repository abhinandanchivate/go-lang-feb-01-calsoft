package models

// slice/ array / struct
type Customer struct {
	ID int
	Name string
	PhoneNumber string
	Balance float64

}