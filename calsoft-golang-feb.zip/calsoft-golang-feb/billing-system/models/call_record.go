package models

import "time"

type CallRecord struct{

	CallID int
	CustomerID int
	Duration float32
	CostPerMinute float32
	Timestamp time.Time
}