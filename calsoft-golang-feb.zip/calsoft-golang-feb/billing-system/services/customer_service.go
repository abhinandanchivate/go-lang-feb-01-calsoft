package services

import (
	"billing-system/models"
	"billing-system/repository"
)

// we have to write the interface

type TelecomService interface {

	AddCustomer(customer models.Customer)(models.Customer,error)
	GetCustomerDetails(customerID int)(models.Customer,error)
	MakeCall(callRecord models.CallRecord)(models.CallRecord,error)
	GenerateBill(customerId int)(float32, error)
}

// will write 1 impl in this file 
// want to write the impl in another file

type TelecomServiceImpl struct {
}

func (TelecomServiceImpl) AddCustomer(customer models.Customer)(models.Customer,error){
return repository.CreateCustomer(customer)
}

func (TelecomServiceImpl) GetCustomerDetails(customerID int)(models.Customer,error){
return repository.GetCustomerDetails(customerID)
}


func (TelecomServiceImpl) MakeCall(callRecord models.CallRecord)(models.CallRecord,error){
	return models.CallRecord{}, nil
}

func (TelecomServiceImpl) GenerateBill(customerId int)(float32, error){
	return 0, nil
	}