package repository

import (
	"billing-system/models"
	"errors"
)

// slice is expected to hold the in memory
// 1 : custDetails
// 2: custDetails
// 3: custDetails
// 4: custDetails
// 5: custDetails
// we are not currently using DB.

var CustomerDB = make(map[int]models.Customer)
// act like a DB

func CreateCustomer(customer models.Customer) (models.Customer,error) {
	// check if customer already exists
	// boolean exists 
	// customer c2;
	// exists = stream 
	// if (exits ){} else {}
	
	if _,exists := CustomerDB[customer.ID]; exists  {
		return models.Customer{}, errors.New("Customer already exists")
	} // model.Customer  : return in the stack 

	CustomerDB[customer.ID] = customer

	return customer, nil
	
	// in go used to check the key exists in the map or not .

	// _ igore 
	// CustomerDB : map
	// customer.Id : key
	// exists : boolean var ==> true if customer.Id exists in the customerDB 
	// false otherwise situation.
	
	
}

// getCustomer Details on the basis of id

func GetCustomerDetails(id int) (models.Customer,error) {
customer, exists := CustomerDB[id]
	if !exists {
		return models.Customer{}, errors.New("customer not found")
	}
	return customer, nil
}

// retrieve all customer details 
func GetAllCustomerDetails() ([]models.Customer,error) {
	// map ===> all customer structs.
	// we need slice of customer structs.
	// slice , array , map ===> nil 
	// struct == primitive ==> no nil 
	// pointer
	var customers []models.Customer

	for _,customer :=range CustomerDB {
	
		customers= append(customers,customer)
	}

	if len(customers) == 0 {
		return nil, errors.New("no customers found")
	}
	return customers, nil

	// if we have the data ==> add it slice 
	// if not return error

	

}

// /// update customer details 
// func UpdateCustomerDetails(id int, customer models.Customer) (error) {

// }

