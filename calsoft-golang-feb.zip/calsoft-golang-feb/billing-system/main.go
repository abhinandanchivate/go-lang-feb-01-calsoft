package main

import (
	"billing-system/models"
	"billing-system/services"
	"fmt"
)
func main()  {
	// services in the main
	//service := services.telecomServiceImpl


	service :=services.TelecomServiceImpl{}
	// Adding Customers
	model_Customer1:= models.Customer{1, "Alice", "9876543210", 50.0}
	model_Customer2:= models.Customer{2, "Bob", "1234567890", 100}

	cust1,_:=service.AddCustomer(model_Customer1)
	cust2,_:=service.AddCustomer(model_Customer2)


	fmt.Println("customers added",cust1,cust2)
	
}