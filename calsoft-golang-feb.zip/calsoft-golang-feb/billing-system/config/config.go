// db related work ---No
package config

const (
	CallCostPerMinute =0.5 // fixed call rate
)
