package main

import (
	"fmt"
	"unsafe"
)

type  Person struct {
	name string
	age int
}
func main3() {
/*
Use Type Inference When:

The type is obvious from the assignment.
You want cleaner and more concise code.
You're working with short-lived variables inside functions.
*/
	// a:= 10
	// b:= 10.5
	// c:= "Hello"
	// fmt.Println(a)
	// fmt.Println(b)
	// fmt.Println(c)

	//var a int = 10
	var b float32 = 10.5123456789
	//  c := "Hello"

	//  c= "World"
	//  var p Person
	//  var x int 
	//  var y string
	 fmt.Println(unsafe.Sizeof(b))
	//  fmt.Println(unsafe.Sizeof(x))
	//  fmt.Println(unsafe.Sizeof(y))

	//  fmt.Println(unsafe.Sizeof(p))
	// fmt.Printf("a=%d , b=%d , c=%d\n",unsafe.Sizeof(a) ,unsafe.Sizeof(b) ,unsafe.Sizeof(c))
	// fmt.Println()
	// fmt.Println(reflect.TypeOf(a))

}