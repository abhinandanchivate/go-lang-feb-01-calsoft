package main

import "fmt"

func main7() {
    var r rune = 'A'  // rune is an alias for int32
    var b byte = 'B'  // byte is an alias for uint8
	// to store the character value in that case we should declare the variable as rune
	// char is not a data type in go
	// char can be stored in rune/ byte
	var emoji rune = '😂'
	fmt.Printf("%c",emoji) // 128514
    fmt.Println(r, string(r), b, string(b)) // 65 A 66 B
}