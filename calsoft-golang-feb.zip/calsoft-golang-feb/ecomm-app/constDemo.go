package main

import (
	"fmt"
)

func main5() {
const PI = 3.14159
const GREETING = "Hello, World!"
PI = 3.0
fmt.Println(PI)
fmt.Println(GREETING)

}
/*
Integer Types

int, int8, int16, int32, int64 → Signed integers
uint, uint8, uint16, uint32, uint64 → Unsigned integers
*/