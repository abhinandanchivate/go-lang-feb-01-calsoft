package main

import "fmt"

func main6() {
    var i int
    var f float64
    var b bool
    var s string
    fmt.Println(i, f, b, s) // 0 0 false ""
}
