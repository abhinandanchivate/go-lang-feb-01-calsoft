// package
package main

// import
import (
	"fmt"
)

// db cofig
// routings
// services
// repo
// models
// main

func main1() {
	// variable : to declare a variable in go, we use 
	//1. var keyword, 
	//2. short declaration operator :=
	//3. const keyword
	var x float32 = 10.5
	var y bool = true
	var z string = "Hello"
	fmt.Println(x)
	fmt.Println(y)
	fmt.Println(z)

	
	fmt.Println(x)
}