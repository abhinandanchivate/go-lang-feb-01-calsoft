package main

import "fmt"

const (
    A = 201 +(iota * 10)  // 0
    B       // 1 201 + 1* 10 = 211

    C   =500 + (iota*10)     // 2 201 + 2* 10 = 221
    D         // 3 201 + 3* 10 = 231
)
const (
    Sunday = iota  // 0
    Monday         // 1
    Tuesday        // 2
    Wednesday      // 3
    Thursday       // 4
    Friday         // 5
    Saturday       // 6
)
const (
	// 1 ==> beginner
	// 2 ==> intermediate
	// 3 ==> advanced
	_ = iota
	BEGINNER
	INTERMEDIATE
	_= iota
	_= iota
	ADVANCED
)
func main() {
   fmt.Println(BEGINNER, INTERMEDIATE-1, ADVANCED-3)
}
